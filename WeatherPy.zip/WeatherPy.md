
Analysis

Based on the latitude versus temperature graph, warmer temperatures are seen closer to the equator which is near zero degrees 
latitude.

Windspeed also tends to be lower near the equator as well.

There is also a higher percentage of humidity near the equator.


```python
# Dependencies
import matplotlib.pyplot as plt
import requests
import json
import numpy as np
import pandas as pd
from config import api_key
from citipy import citipy
```


```python
#generate random coordinates to use for cities list
rand_coordinates = [( np.random.uniform(-90,90 ), np.random.uniform(-180,180) ) for k in range(1400)]
```


```python
cities = []
for coordinate_pair in rand_coordinates:
    lat, long = coordinate_pair
    cities.append(citipy.nearest_city(lat, long))
    
```


```python
cities_list=[]
for city in cities:
    country_code = city.country_code
    name = city.city_name
    cities_list.append(name)
    
```


```python
actual_cities_list=[]
for city in cities_list:
    if city not in actual_cities_list:
        actual_cities_list.append(city)
```


```python
# Get current weather

url = "http://api.openweathermap.org/data/2.5/weather?"
units = "imperial"

# Build partial query URL
query_url = f"{url}appid={api_key}&units={units}&q="


```


```python
# set up lists to hold reponse info
city_name=[]
lat = []
temperature=[]
cloudiness=[]
windspeed=[]
humidity=[]
count=1
for city in actual_cities_list:
    print(f"Processing Record number {count} | {city}")
    print(query_url + str(city))
    count+=1
    
print("-------------------------")
print("Data Retrieval Complete")
print("-------------------------")

    
    
```

    Processing Record number 1 | qaanaaq
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=qaanaaq
    Processing Record number 2 | east london
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=east london
    Processing Record number 3 | sinnamary
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sinnamary
    Processing Record number 4 | klaksvik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=klaksvik
    Processing Record number 5 | norman wells
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=norman wells
    Processing Record number 6 | roros
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=roros
    Processing Record number 7 | rikitea
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=rikitea
    Processing Record number 8 | jiazi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jiazi
    Processing Record number 9 | ust-maya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ust-maya
    Processing Record number 10 | atuona
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=atuona
    Processing Record number 11 | olafsvik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=olafsvik
    Processing Record number 12 | saint-philippe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint-philippe
    Processing Record number 13 | bengkulu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bengkulu
    Processing Record number 14 | nanded
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nanded
    Processing Record number 15 | clyde river
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=clyde river
    Processing Record number 16 | avarua
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=avarua
    Processing Record number 17 | alice springs
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=alice springs
    Processing Record number 18 | mataura
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mataura
    Processing Record number 19 | vaitupu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vaitupu
    Processing Record number 20 | makakilo city
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=makakilo city
    Processing Record number 21 | maarianhamina
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=maarianhamina
    Processing Record number 22 | beringovskiy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=beringovskiy
    Processing Record number 23 | bukama
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bukama
    Processing Record number 24 | pacific grove
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pacific grove
    Processing Record number 25 | punta arenas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=punta arenas
    Processing Record number 26 | faanui
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=faanui
    Processing Record number 27 | port alfred
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=port alfred
    Processing Record number 28 | taolanaro
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=taolanaro
    Processing Record number 29 | ushuaia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ushuaia
    Processing Record number 30 | dikson
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dikson
    Processing Record number 31 | albany
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=albany
    Processing Record number 32 | bluff
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bluff
    Processing Record number 33 | geraldton
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=geraldton
    Processing Record number 34 | akyab
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=akyab
    Processing Record number 35 | hobart
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hobart
    Processing Record number 36 | richards bay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=richards bay
    Processing Record number 37 | stoyba
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=stoyba
    Processing Record number 38 | ancud
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ancud
    Processing Record number 39 | mar del plata
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mar del plata
    Processing Record number 40 | cherskiy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cherskiy
    Processing Record number 41 | puyang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=puyang
    Processing Record number 42 | torbay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=torbay
    Processing Record number 43 | puerto escondido
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=puerto escondido
    Processing Record number 44 | ponta delgada
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ponta delgada
    Processing Record number 45 | port lincoln
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=port lincoln
    Processing Record number 46 | hithadhoo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hithadhoo
    Processing Record number 47 | chagda
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chagda
    Processing Record number 48 | maceio
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=maceio
    Processing Record number 49 | ponta do sol
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ponta do sol
    Processing Record number 50 | la asuncion
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=la asuncion
    Processing Record number 51 | new norfolk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=new norfolk
    Processing Record number 52 | sungaipenuh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sungaipenuh
    Processing Record number 53 | tasiilaq
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tasiilaq
    Processing Record number 54 | tuatapere
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tuatapere
    Processing Record number 55 | aykhal
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=aykhal
    Processing Record number 56 | sheltozero
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sheltozero
    Processing Record number 57 | jamestown
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jamestown
    Processing Record number 58 | vaini
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vaini
    Processing Record number 59 | tarakan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tarakan
    Processing Record number 60 | sao miguel do oeste
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sao miguel do oeste
    Processing Record number 61 | chanika
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chanika
    Processing Record number 62 | along
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=along
    Processing Record number 63 | saskylakh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saskylakh
    Processing Record number 64 | ambulu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ambulu
    Processing Record number 65 | sitka
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sitka
    Processing Record number 66 | san ramon
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=san ramon
    Processing Record number 67 | kodiak
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kodiak
    Processing Record number 68 | guerrero negro
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=guerrero negro
    Processing Record number 69 | khatanga
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=khatanga
    Processing Record number 70 | samalaeulu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=samalaeulu
    Processing Record number 71 | naze
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=naze
    Processing Record number 72 | yerbogachen
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=yerbogachen
    Processing Record number 73 | maneadero
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=maneadero
    Processing Record number 74 | lazaro cardenas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lazaro cardenas
    Processing Record number 75 | hilo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hilo
    Processing Record number 76 | banda aceh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=banda aceh
    Processing Record number 77 | aksu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=aksu
    Processing Record number 78 | bredasdorp
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bredasdorp
    Processing Record number 79 | puerto ayora
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=puerto ayora
    Processing Record number 80 | arraial do cabo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=arraial do cabo
    Processing Record number 81 | medeiros neto
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=medeiros neto
    Processing Record number 82 | kavaratti
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kavaratti
    Processing Record number 83 | busselton
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=busselton
    Processing Record number 84 | lanzhou
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lanzhou
    Processing Record number 85 | prince george
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=prince george
    Processing Record number 86 | hualmay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hualmay
    Processing Record number 87 | kapustin yar-1
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kapustin yar-1
    Processing Record number 88 | marana
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=marana
    Processing Record number 89 | fortuna
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=fortuna
    Processing Record number 90 | tuktoyaktuk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tuktoyaktuk
    Processing Record number 91 | kangaatsiaq
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kangaatsiaq
    Processing Record number 92 | comodoro rivadavia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=comodoro rivadavia
    Processing Record number 93 | nagorsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nagorsk
    Processing Record number 94 | husavik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=husavik
    Processing Record number 95 | ribeira grande
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ribeira grande
    Processing Record number 96 | belushya guba
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=belushya guba
    Processing Record number 97 | grand river south east
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=grand river south east
    Processing Record number 98 | kiunga
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kiunga
    Processing Record number 99 | arcachon
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=arcachon
    Processing Record number 100 | toktogul
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=toktogul
    Processing Record number 101 | havre-saint-pierre
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=havre-saint-pierre
    Processing Record number 102 | abong mbang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=abong mbang
    Processing Record number 103 | palmer
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=palmer
    Processing Record number 104 | kununurra
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kununurra
    Processing Record number 105 | mantua
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mantua
    Processing Record number 106 | buala
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=buala
    Processing Record number 107 | atar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=atar
    Processing Record number 108 | santa maria
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=santa maria
    Processing Record number 109 | kieta
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kieta
    Processing Record number 110 | san andres
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=san andres
    Processing Record number 111 | tiksi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tiksi
    Processing Record number 112 | nikolskoye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nikolskoye
    Processing Record number 113 | lima
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lima
    Processing Record number 114 | natal
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=natal
    Processing Record number 115 | saint-die
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint-die
    Processing Record number 116 | yellowknife
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=yellowknife
    Processing Record number 117 | salalah
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=salalah
    Processing Record number 118 | sao geraldo do araguaia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sao geraldo do araguaia
    Processing Record number 119 | cape town
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cape town
    Processing Record number 120 | saint george
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint george
    Processing Record number 121 | omboue
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=omboue
    Processing Record number 122 | kavieng
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kavieng
    Processing Record number 123 | khonuu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=khonuu
    Processing Record number 124 | bethel
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bethel
    Processing Record number 125 | mount isa
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mount isa
    Processing Record number 126 | butaritari
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=butaritari
    Processing Record number 127 | nouadhibou
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nouadhibou
    Processing Record number 128 | nezhinka
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nezhinka
    Processing Record number 129 | pontianak
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pontianak
    Processing Record number 130 | santiago
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=santiago
    Processing Record number 131 | illoqqortoormiut
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=illoqqortoormiut
    Processing Record number 132 | pierre
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pierre
    Processing Record number 133 | key largo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=key largo
    Processing Record number 134 | iqaluit
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=iqaluit
    Processing Record number 135 | alta floresta
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=alta floresta
    Processing Record number 136 | talaya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=talaya
    Processing Record number 137 | mitsamiouli
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mitsamiouli
    Processing Record number 138 | napasar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=napasar
    Processing Record number 139 | itarema
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=itarema
    Processing Record number 140 | bilibino
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bilibino
    Processing Record number 141 | niquelandia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=niquelandia
    Processing Record number 142 | puchezh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=puchezh
    Processing Record number 143 | georgetown
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=georgetown
    Processing Record number 144 | narsaq
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=narsaq
    Processing Record number 145 | barrow
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=barrow
    Processing Record number 146 | green river
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=green river
    Processing Record number 147 | artyk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=artyk
    Processing Record number 148 | sebezh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sebezh
    Processing Record number 149 | trairi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=trairi
    Processing Record number 150 | hermanus
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hermanus
    Processing Record number 151 | carnarvon
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=carnarvon
    Processing Record number 152 | deputatskiy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=deputatskiy
    Processing Record number 153 | arkhangelskoye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=arkhangelskoye
    Processing Record number 154 | longyearbyen
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=longyearbyen
    Processing Record number 155 | luderitz
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=luderitz
    Processing Record number 156 | cooma
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cooma
    Processing Record number 157 | asau
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=asau
    Processing Record number 158 | moose factory
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=moose factory
    Processing Record number 159 | katsuura
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=katsuura
    Processing Record number 160 | port elizabeth
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=port elizabeth
    Processing Record number 161 | nemuro
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nemuro
    Processing Record number 162 | novikovo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=novikovo
    Processing Record number 163 | oistins
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=oistins
    Processing Record number 164 | hami
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hami
    Processing Record number 165 | cidreira
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cidreira
    Processing Record number 166 | saint-augustin
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint-augustin
    Processing Record number 167 | yulara
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=yulara
    Processing Record number 168 | krapivinskiy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=krapivinskiy
    Processing Record number 169 | dolbeau
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dolbeau
    Processing Record number 170 | castro
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=castro
    Processing Record number 171 | omsukchan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=omsukchan
    Processing Record number 172 | bumba
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bumba
    Processing Record number 173 | trinidad
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=trinidad
    Processing Record number 174 | xai-xai
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=xai-xai
    Processing Record number 175 | mys shmidta
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mys shmidta
    Processing Record number 176 | caravelas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=caravelas
    Processing Record number 177 | jizan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jizan
    Processing Record number 178 | aklavik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=aklavik
    Processing Record number 179 | amderma
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=amderma
    Processing Record number 180 | gobabis
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gobabis
    Processing Record number 181 | attawapiskat
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=attawapiskat
    Processing Record number 182 | nenjiang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nenjiang
    Processing Record number 183 | srednekolymsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=srednekolymsk
    Processing Record number 184 | te anau
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=te anau
    Processing Record number 185 | bereda
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bereda
    Processing Record number 186 | kilindoni
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kilindoni
    Processing Record number 187 | erenhot
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=erenhot
    Processing Record number 188 | krasnoshchekovo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=krasnoshchekovo
    Processing Record number 189 | wronki
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=wronki
    Processing Record number 190 | ust-nera
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ust-nera
    Processing Record number 191 | mehamn
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mehamn
    Processing Record number 192 | meulaboh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=meulaboh
    Processing Record number 193 | matay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=matay
    Processing Record number 194 | rawson
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=rawson
    Processing Record number 195 | mayo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mayo
    Processing Record number 196 | brae
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=brae
    Processing Record number 197 | pimentel
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pimentel
    Processing Record number 198 | lompoc
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lompoc
    Processing Record number 199 | iracoubo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=iracoubo
    Processing Record number 200 | kalmar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kalmar
    Processing Record number 201 | qixia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=qixia
    Processing Record number 202 | kiama
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kiama
    Processing Record number 203 | samusu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=samusu
    Processing Record number 204 | komsomolskiy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=komsomolskiy
    Processing Record number 205 | chokurdakh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chokurdakh
    Processing Record number 206 | nanortalik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nanortalik
    Processing Record number 207 | terme
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=terme
    Processing Record number 208 | bambous virieux
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bambous virieux
    Processing Record number 209 | tubruq
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tubruq
    Processing Record number 210 | esperance
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=esperance
    Processing Record number 211 | skalistyy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=skalistyy
    Processing Record number 212 | arkhangelsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=arkhangelsk
    Processing Record number 213 | cavalcante
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cavalcante
    Processing Record number 214 | thompson
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=thompson
    Processing Record number 215 | upernavik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=upernavik
    Processing Record number 216 | coahuayana
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=coahuayana
    Processing Record number 217 | kapaa
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kapaa
    Processing Record number 218 | lamu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lamu
    Processing Record number 219 | los llanos de aridane
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=los llanos de aridane
    Processing Record number 220 | halalo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=halalo
    Processing Record number 221 | xining
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=xining
    Processing Record number 222 | aksehir
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=aksehir
    Processing Record number 223 | benghazi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=benghazi
    Processing Record number 224 | chuy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chuy
    Processing Record number 225 | inirida
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=inirida
    Processing Record number 226 | pathein
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pathein
    Processing Record number 227 | andros town
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=andros town
    Processing Record number 228 | turkmenabat
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=turkmenabat
    Processing Record number 229 | saldanha
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saldanha
    Processing Record number 230 | hirara
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hirara
    Processing Record number 231 | adrar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=adrar
    Processing Record number 232 | alofi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=alofi
    Processing Record number 233 | ketchikan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ketchikan
    Processing Record number 234 | labuhan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=labuhan
    Processing Record number 235 | san patricio
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=san patricio
    Processing Record number 236 | longjiang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=longjiang
    Processing Record number 237 | kruisfontein
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kruisfontein
    Processing Record number 238 | itaituba
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=itaituba
    Processing Record number 239 | chimbote
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chimbote
    Processing Record number 240 | solikamsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=solikamsk
    Processing Record number 241 | victoria
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=victoria
    Processing Record number 242 | san roque
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=san roque
    Processing Record number 243 | yibin
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=yibin
    Processing Record number 244 | gornopravdinsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gornopravdinsk
    Processing Record number 245 | flinders
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=flinders
    Processing Record number 246 | saiha
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saiha
    Processing Record number 247 | goma
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=goma
    Processing Record number 248 | pagondas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pagondas
    Processing Record number 249 | mount gambier
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mount gambier
    Processing Record number 250 | izazi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=izazi
    Processing Record number 251 | sarangani
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sarangani
    Processing Record number 252 | pevek
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pevek
    Processing Record number 253 | bonavista
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bonavista
    Processing Record number 254 | egvekinot
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=egvekinot
    Processing Record number 255 | mananara
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mananara
    Processing Record number 256 | lebu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lebu
    Processing Record number 257 | dingle
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dingle
    Processing Record number 258 | umm lajj
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=umm lajj
    Processing Record number 259 | saint-pierre
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint-pierre
    Processing Record number 260 | kita
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kita
    Processing Record number 261 | ostersund
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ostersund
    Processing Record number 262 | igarka
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=igarka
    Processing Record number 263 | abu samrah
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=abu samrah
    Processing Record number 264 | cao bang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cao bang
    Processing Record number 265 | nizhneyansk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nizhneyansk
    Processing Record number 266 | bintulu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bintulu
    Processing Record number 267 | toliary
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=toliary
    Processing Record number 268 | mogadishu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mogadishu
    Processing Record number 269 | codrington
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=codrington
    Processing Record number 270 | gizo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gizo
    Processing Record number 271 | vanavara
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vanavara
    Processing Record number 272 | naryan-mar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=naryan-mar
    Processing Record number 273 | tecoanapa
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tecoanapa
    Processing Record number 274 | bubaque
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bubaque
    Processing Record number 275 | sangar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sangar
    Processing Record number 276 | la palma
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=la palma
    Processing Record number 277 | usinsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=usinsk
    Processing Record number 278 | dehloran
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dehloran
    Processing Record number 279 | minusinsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=minusinsk
    Processing Record number 280 | mezhdurechensk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mezhdurechensk
    Processing Record number 281 | broome
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=broome
    Processing Record number 282 | piacabucu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=piacabucu
    Processing Record number 283 | maumere
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=maumere
    Processing Record number 284 | terrace
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=terrace
    Processing Record number 285 | emerald
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=emerald
    Processing Record number 286 | mabaruma
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mabaruma
    Processing Record number 287 | yakshur-bodya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=yakshur-bodya
    Processing Record number 288 | rocha
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=rocha
    Processing Record number 289 | ravar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ravar
    Processing Record number 290 | barentsburg
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=barentsburg
    Processing Record number 291 | touros
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=touros
    Processing Record number 292 | lisakovsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lisakovsk
    Processing Record number 293 | muncar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=muncar
    Processing Record number 294 | el cobre
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=el cobre
    Processing Record number 295 | benjamin aceval
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=benjamin aceval
    Processing Record number 296 | kawalu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kawalu
    Processing Record number 297 | muros
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=muros
    Processing Record number 298 | santa rosa
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=santa rosa
    Processing Record number 299 | sola
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sola
    Processing Record number 300 | ous
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ous
    Processing Record number 301 | zhanaozen
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=zhanaozen
    Processing Record number 302 | north bend
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=north bend
    Processing Record number 303 | mayor pablo lagerenza
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mayor pablo lagerenza
    Processing Record number 304 | coihaique
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=coihaique
    Processing Record number 305 | grand gaube
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=grand gaube
    Processing Record number 306 | kijang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kijang
    Processing Record number 307 | port moresby
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=port moresby
    Processing Record number 308 | tabarqah
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tabarqah
    Processing Record number 309 | nabire
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nabire
    Processing Record number 310 | houston
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=houston
    Processing Record number 311 | urumqi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=urumqi
    Processing Record number 312 | marquette
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=marquette
    Processing Record number 313 | pangnirtung
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pangnirtung
    Processing Record number 314 | mago
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mago
    Processing Record number 315 | veraval
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=veraval
    Processing Record number 316 | mbekenyera
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mbekenyera
    Processing Record number 317 | lakes entrance
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lakes entrance
    Processing Record number 318 | poum
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=poum
    Processing Record number 319 | zambezi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=zambezi
    Processing Record number 320 | buariki
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=buariki
    Processing Record number 321 | newport
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=newport
    Processing Record number 322 | kimbe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kimbe
    Processing Record number 323 | poddorye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=poddorye
    Processing Record number 324 | gisenyi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gisenyi
    Processing Record number 325 | najran
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=najran
    Processing Record number 326 | chara
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chara
    Processing Record number 327 | villamontes
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=villamontes
    Processing Record number 328 | tsihombe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tsihombe
    Processing Record number 329 | talnakh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=talnakh
    Processing Record number 330 | meyungs
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=meyungs
    Processing Record number 331 | moses lake
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=moses lake
    Processing Record number 332 | svencionys
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=svencionys
    Processing Record number 333 | datong
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=datong
    Processing Record number 334 | hearst
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hearst
    Processing Record number 335 | sapao
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sapao
    Processing Record number 336 | airai
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=airai
    Processing Record number 337 | suntar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=suntar
    Processing Record number 338 | katherine
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=katherine
    Processing Record number 339 | ust-kuyga
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ust-kuyga
    Processing Record number 340 | tateyama
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tateyama
    Processing Record number 341 | kirov
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kirov
    Processing Record number 342 | nadapuram
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nadapuram
    Processing Record number 343 | balas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=balas
    Processing Record number 344 | omaruru
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=omaruru
    Processing Record number 345 | atsiki
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=atsiki
    Processing Record number 346 | kirakira
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kirakira
    Processing Record number 347 | izvestkovyy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=izvestkovyy
    Processing Record number 348 | salinopolis
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=salinopolis
    Processing Record number 349 | stepnogorsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=stepnogorsk
    Processing Record number 350 | barcelos
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=barcelos
    Processing Record number 351 | sur
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sur
    Processing Record number 352 | abha
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=abha
    Processing Record number 353 | krasnoselkup
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=krasnoselkup
    Processing Record number 354 | lauro muller
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lauro muller
    Processing Record number 355 | songjianghe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=songjianghe
    Processing Record number 356 | chitral
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chitral
    Processing Record number 357 | sao filipe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sao filipe
    Processing Record number 358 | portland
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=portland
    Processing Record number 359 | provideniya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=provideniya
    Processing Record number 360 | riyadh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=riyadh
    Processing Record number 361 | bismarck
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bismarck
    Processing Record number 362 | tiznit
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tiznit
    Processing Record number 363 | lujiang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lujiang
    Processing Record number 364 | seoul
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=seoul
    Processing Record number 365 | sao joao da barra
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sao joao da barra
    Processing Record number 366 | babushkin
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=babushkin
    Processing Record number 367 | saint-francois
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint-francois
    Processing Record number 368 | plettenberg bay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=plettenberg bay
    Processing Record number 369 | lorengau
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lorengau
    Processing Record number 370 | gilgit
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gilgit
    Processing Record number 371 | soure
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=soure
    Processing Record number 372 | homer
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=homer
    Processing Record number 373 | mahebourg
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mahebourg
    Processing Record number 374 | katobu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=katobu
    Processing Record number 375 | lagoa
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lagoa
    Processing Record number 376 | tashtagol
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tashtagol
    Processing Record number 377 | ngukurr
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ngukurr
    Processing Record number 378 | aflu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=aflu
    Processing Record number 379 | conde
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=conde
    Processing Record number 380 | compostela
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=compostela
    Processing Record number 381 | kamaishi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kamaishi
    Processing Record number 382 | stephenville
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=stephenville
    Processing Record number 383 | susangerd
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=susangerd
    Processing Record number 384 | hofn
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hofn
    Processing Record number 385 | barawe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=barawe
    Processing Record number 386 | jaguaruna
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jaguaruna
    Processing Record number 387 | mizpe ramon
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mizpe ramon
    Processing Record number 388 | wanning
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=wanning
    Processing Record number 389 | coria
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=coria
    Processing Record number 390 | sumbe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sumbe
    Processing Record number 391 | jatai
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jatai
    Processing Record number 392 | polczyn-zdroj
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=polczyn-zdroj
    Processing Record number 393 | pinar del rio
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pinar del rio
    Processing Record number 394 | fuyang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=fuyang
    Processing Record number 395 | berlevag
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=berlevag
    Processing Record number 396 | buchanan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=buchanan
    Processing Record number 397 | bara
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bara
    Processing Record number 398 | olga
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=olga
    Processing Record number 399 | san quintin
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=san quintin
    Processing Record number 400 | lavrentiya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lavrentiya
    Processing Record number 401 | sawtell
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sawtell
    Processing Record number 402 | coquimbo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=coquimbo
    Processing Record number 403 | liku
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=liku
    Processing Record number 404 | tungor
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tungor
    Processing Record number 405 | terney
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=terney
    Processing Record number 406 | sentyabrskiy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sentyabrskiy
    Processing Record number 407 | severo-kurilsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=severo-kurilsk
    Processing Record number 408 | oshakati
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=oshakati
    Processing Record number 409 | teguldet
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=teguldet
    Processing Record number 410 | pundaguitan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pundaguitan
    Processing Record number 411 | lamin
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lamin
    Processing Record number 412 | kamenskoye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kamenskoye
    Processing Record number 413 | muroto
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=muroto
    Processing Record number 414 | tessalit
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tessalit
    Processing Record number 415 | vila velha
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vila velha
    Processing Record number 416 | alyangula
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=alyangula
    Processing Record number 417 | virginia beach
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=virginia beach
    Processing Record number 418 | waldoboro
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=waldoboro
    Processing Record number 419 | morant bay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=morant bay
    Processing Record number 420 | batemans bay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=batemans bay
    Processing Record number 421 | zittau
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=zittau
    Processing Record number 422 | inza
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=inza
    Processing Record number 423 | reconquista
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=reconquista
    Processing Record number 424 | bardiyah
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bardiyah
    Processing Record number 425 | synya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=synya
    Processing Record number 426 | pandan niog
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pandan niog
    Processing Record number 427 | talavera
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=talavera
    Processing Record number 428 | koslan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=koslan
    Processing Record number 429 | arrifes
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=arrifes
    Processing Record number 430 | gongzhuling
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gongzhuling
    Processing Record number 431 | port macquarie
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=port macquarie
    Processing Record number 432 | tukrah
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tukrah
    Processing Record number 433 | khoy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=khoy
    Processing Record number 434 | tura
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tura
    Processing Record number 435 | kaitangata
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kaitangata
    Processing Record number 436 | rafai
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=rafai
    Processing Record number 437 | arlit
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=arlit
    Processing Record number 438 | rock sound
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=rock sound
    Processing Record number 439 | vila
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vila
    Processing Record number 440 | tumannyy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tumannyy
    Processing Record number 441 | tabas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tabas
    Processing Record number 442 | dobryatino
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dobryatino
    Processing Record number 443 | wewak
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=wewak
    Processing Record number 444 | svetlyy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=svetlyy
    Processing Record number 445 | haines junction
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=haines junction
    Processing Record number 446 | la ronge
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=la ronge
    Processing Record number 447 | yambio
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=yambio
    Processing Record number 448 | vestmannaeyjar
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vestmannaeyjar
    Processing Record number 449 | winnemucca
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=winnemucca
    Processing Record number 450 | petropavlovsk-kamchatskiy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=petropavlovsk-kamchatskiy
    Processing Record number 451 | carbonia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=carbonia
    Processing Record number 452 | dunedin
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dunedin
    Processing Record number 453 | lyangasovo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lyangasovo
    Processing Record number 454 | gondanglegi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gondanglegi
    Processing Record number 455 | nome
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nome
    Processing Record number 456 | san policarpo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=san policarpo
    Processing Record number 457 | abu jubayhah
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=abu jubayhah
    Processing Record number 458 | sao gabriel da cachoeira
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sao gabriel da cachoeira
    Processing Record number 459 | hasaki
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hasaki
    Processing Record number 460 | myurego
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=myurego
    Processing Record number 461 | schwechat
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=schwechat
    Processing Record number 462 | ararat
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ararat
    Processing Record number 463 | ursulo galvan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ursulo galvan
    Processing Record number 464 | svetlograd
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=svetlograd
    Processing Record number 465 | umm ruwabah
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=umm ruwabah
    Processing Record number 466 | oussouye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=oussouye
    Processing Record number 467 | oranjemund
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=oranjemund
    Processing Record number 468 | vao
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vao
    Processing Record number 469 | mildura
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mildura
    Processing Record number 470 | zhigansk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=zhigansk
    Processing Record number 471 | kuruman
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kuruman
    Processing Record number 472 | magnitka
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=magnitka
    Processing Record number 473 | port hardy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=port hardy
    Processing Record number 474 | vila franca do campo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=vila franca do campo
    Processing Record number 475 | tonj
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tonj
    Processing Record number 476 | acapulco
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=acapulco
    Processing Record number 477 | sistranda
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sistranda
    Processing Record number 478 | noyabrsk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=noyabrsk
    Processing Record number 479 | arani
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=arani
    Processing Record number 480 | cabo san lucas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cabo san lucas
    Processing Record number 481 | kuytun
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kuytun
    Processing Record number 482 | kerteh
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kerteh
    Processing Record number 483 | mersing
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mersing
    Processing Record number 484 | eydhafushi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=eydhafushi
    Processing Record number 485 | nortelandia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nortelandia
    Processing Record number 486 | wattegama
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=wattegama
    Processing Record number 487 | kargasok
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kargasok
    Processing Record number 488 | dese
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dese
    Processing Record number 489 | avera
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=avera
    Processing Record number 490 | ishigaki
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ishigaki
    Processing Record number 491 | puerto leguizamo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=puerto leguizamo
    Processing Record number 492 | isangel
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=isangel
    Processing Record number 493 | sembe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sembe
    Processing Record number 494 | kaseda
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kaseda
    Processing Record number 495 | slave lake
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=slave lake
    Processing Record number 496 | okha
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=okha
    Processing Record number 497 | naigarhi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=naigarhi
    Processing Record number 498 | coruripe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=coruripe
    Processing Record number 499 | iberia
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=iberia
    Processing Record number 500 | chongwe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chongwe
    Processing Record number 501 | svetlaya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=svetlaya
    Processing Record number 502 | tupik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tupik
    Processing Record number 503 | kochubey
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kochubey
    Processing Record number 504 | orocue
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=orocue
    Processing Record number 505 | mana
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mana
    Processing Record number 506 | henties bay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=henties bay
    Processing Record number 507 | rabo de peixe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=rabo de peixe
    Processing Record number 508 | saint anthony
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint anthony
    Processing Record number 509 | george town
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=george town
    Processing Record number 510 | carauari
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=carauari
    Processing Record number 511 | huarmey
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=huarmey
    Processing Record number 512 | falealupo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=falealupo
    Processing Record number 513 | ampanihy
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ampanihy
    Processing Record number 514 | padang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=padang
    Processing Record number 515 | saint-joseph
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=saint-joseph
    Processing Record number 516 | williams lake
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=williams lake
    Processing Record number 517 | faya
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=faya
    Processing Record number 518 | harper
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=harper
    Processing Record number 519 | lac du bonnet
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lac du bonnet
    Processing Record number 520 | dolgoderevenskoye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dolgoderevenskoye
    Processing Record number 521 | port shepstone
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=port shepstone
    Processing Record number 522 | kahului
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kahului
    Processing Record number 523 | honningsvag
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=honningsvag
    Processing Record number 524 | tilichiki
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tilichiki
    Processing Record number 525 | bac lieu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bac lieu
    Processing Record number 526 | kamenka
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kamenka
    Processing Record number 527 | berberati
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=berberati
    Processing Record number 528 | tsuruoka
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tsuruoka
    Processing Record number 529 | asuncion
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=asuncion
    Processing Record number 530 | namibe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=namibe
    Processing Record number 531 | cayenne
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cayenne
    Processing Record number 532 | dayong
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=dayong
    Processing Record number 533 | lata
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lata
    Processing Record number 534 | bahia blanca
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=bahia blanca
    Processing Record number 535 | tautira
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tautira
    Processing Record number 536 | awbari
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=awbari
    Processing Record number 537 | kendari
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kendari
    Processing Record number 538 | necochea
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=necochea
    Processing Record number 539 | muzhi
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=muzhi
    Processing Record number 540 | kaeo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kaeo
    Processing Record number 541 | shimoda
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=shimoda
    Processing Record number 542 | mola di bari
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=mola di bari
    Processing Record number 543 | sioux lookout
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sioux lookout
    Processing Record number 544 | luwingu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=luwingu
    Processing Record number 545 | kindu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kindu
    Processing Record number 546 | tongliao
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tongliao
    Processing Record number 547 | kudamatsu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kudamatsu
    Processing Record number 548 | jesup
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jesup
    Processing Record number 549 | talara
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=talara
    Processing Record number 550 | nantucket
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nantucket
    Processing Record number 551 | ariquemes
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ariquemes
    Processing Record number 552 | ilebo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=ilebo
    Processing Record number 553 | maltahohe
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=maltahohe
    Processing Record number 554 | roma
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=roma
    Processing Record number 555 | krasnoye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=krasnoye
    Processing Record number 556 | chicama
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=chicama
    Processing Record number 557 | kantang
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kantang
    Processing Record number 558 | campos belos
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=campos belos
    Processing Record number 559 | agadir
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=agadir
    Processing Record number 560 | kunashak
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kunashak
    Processing Record number 561 | oriximina
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=oriximina
    Processing Record number 562 | turukhansk
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=turukhansk
    Processing Record number 563 | sao paulo de olivenca
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sao paulo de olivenca
    Processing Record number 564 | orotukan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=orotukan
    Processing Record number 565 | sao jose da coroa grande
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sao jose da coroa grande
    Processing Record number 566 | nalut
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nalut
    Processing Record number 567 | jaca
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jaca
    Processing Record number 568 | katangli
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=katangli
    Processing Record number 569 | belle fourche
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=belle fourche
    Processing Record number 570 | athabasca
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=athabasca
    Processing Record number 571 | manoel urbano
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=manoel urbano
    Processing Record number 572 | pitimbu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pitimbu
    Processing Record number 573 | nuristan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nuristan
    Processing Record number 574 | davila
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=davila
    Processing Record number 575 | maniitsoq
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=maniitsoq
    Processing Record number 576 | nelson bay
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nelson bay
    Processing Record number 577 | boyolangu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=boyolangu
    Processing Record number 578 | huangchuan
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=huangchuan
    Processing Record number 579 | stanilesti
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=stanilesti
    Processing Record number 580 | harrismith
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=harrismith
    Processing Record number 581 | raga
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=raga
    Processing Record number 582 | moscow
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=moscow
    Processing Record number 583 | nacala
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=nacala
    Processing Record number 584 | hatillo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hatillo
    Processing Record number 585 | jalu
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=jalu
    Processing Record number 586 | gjovik
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gjovik
    Processing Record number 587 | hambantota
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hambantota
    Processing Record number 588 | cabedelo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=cabedelo
    Processing Record number 589 | prince rupert
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=prince rupert
    Processing Record number 590 | margate
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=margate
    Processing Record number 591 | gumdag
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=gumdag
    Processing Record number 592 | namatanai
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=namatanai
    Processing Record number 593 | pisco
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=pisco
    Processing Record number 594 | san lawrenz
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=san lawrenz
    Processing Record number 595 | podporozhye
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=podporozhye
    Processing Record number 596 | versailles
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=versailles
    Processing Record number 597 | totness
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=totness
    Processing Record number 598 | tumut
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=tumut
    Processing Record number 599 | sisimiut
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=sisimiut
    Processing Record number 600 | phonhong
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=phonhong
    Processing Record number 601 | healdsburg
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=healdsburg
    Processing Record number 602 | lasa
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=lasa
    Processing Record number 603 | hobyo
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=hobyo
    Processing Record number 604 | kualakapuas
    http://api.openweathermap.org/data/2.5/weather?appid=da9c1ba49a05e30c0a69745575bd9f4f&units=imperial&q=kualakapuas
    -------------------------
    Data Retrieval Complete
    -------------------------
    


```python
# Loop through the list of cities and perform a request for data on each
for n in actual_cities_list:
    response = requests.get(query_url + str(n)).json()
    try:
        lat.append(response['coord']['lat'])
    except:
        continue
    city_name.append(response['name'])
    temperature.append(response['main']['temp'])
    windspeed.append(response['wind']['speed'])
    cloudiness.append(response['clouds']['all'])
    humidity.append(response['main']['humidity'])
```


```python
data_df=pd.DataFrame({"City":city_name,
                      "Latitude":lat,
                      "Temperature":temperature,
                      "Cloudiness":cloudiness,
                      "Windspeed":windspeed,
                      "Humidity":humidity,
                      })
data_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness</th>
      <th>Humidity</th>
      <th>Latitude</th>
      <th>Temperature</th>
      <th>Windspeed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Qaanaaq</td>
      <td>24</td>
      <td>88</td>
      <td>77.48</td>
      <td>-14.98</td>
      <td>4.29</td>
    </tr>
    <tr>
      <th>1</th>
      <td>East London</td>
      <td>40</td>
      <td>78</td>
      <td>-33.02</td>
      <td>71.60</td>
      <td>16.11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sinnamary</td>
      <td>76</td>
      <td>94</td>
      <td>5.38</td>
      <td>79.93</td>
      <td>12.39</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Klaksvik</td>
      <td>92</td>
      <td>100</td>
      <td>62.23</td>
      <td>32.00</td>
      <td>16.11</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Norman Wells</td>
      <td>20</td>
      <td>83</td>
      <td>65.28</td>
      <td>-7.61</td>
      <td>3.36</td>
    </tr>
  </tbody>
</table>
</div>




```python
exported_data=data_df.to_csv('WeatherData.csv')
```


```python
#Latitude vs Temperature scatter plot
x_axis=data_df["Latitude"]
y_axis=data_df["Temperature"]
plt.scatter(x_axis,y_axis)
plt.xlabel("Latitude")
plt.ylabel("Temperature(F)")
plt.title("Latitude vs Temperature")
plt.savefig('LatitudevsTemp')
plt.show()
```


![png](output_11_0.png)



```python
#Latitude vs Humidity
x_axis=data_df["Latitude"]
y_axis=data_df["Humidity"]
plt.scatter(x_axis,y_axis)
plt.xlabel("Latitude")
plt.ylabel("Humidity(%)")
plt.title("Latitude vs Humidity")
plt.savefig("LatitudevsHumidity")
plt.show()
```


![png](output_12_0.png)



```python
#Latitude vs Cloudiness
x_axis=data_df["Latitude"]
y_axis=data_df["Cloudiness"]
plt.scatter(x_axis,y_axis)
plt.xlabel("Latitude")
plt.ylabel("Cloudiness(%)")
plt.title("Latitude vs Cloudiness")
plt.savefig("LatitudevsCloudiness")
plt.show()
```


![png](output_13_0.png)



```python
#Latitude vs Wind Speed
x_axis=data_df["Latitude"]
y_axis=data_df["Windspeed"]
plt.scatter(x_axis,y_axis)
plt.xlabel("Latitude")
plt.ylabel("Windspeed(mph)")
plt.title("Latitude vs Windspeed")
plt.savefig("LatitudevsWindspeed")
plt.show()
```


![png](output_14_0.png)

